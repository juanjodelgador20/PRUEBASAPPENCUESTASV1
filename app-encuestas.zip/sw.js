// Guarda la app en el celular para que abra sin internet.
var VERSION = 'encuestas-v6';
var ARCHIVOS = ['./', 'index.html', 'config.js', 'manifest.json', 'logo-negativo.png', 'icono-192.png', 'icono-512.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(ARCHIVOS); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (url.origin === location.origin) {
    // Primero la red (para recibir cambios); si no hay señal, la copia guardada
    e.respondWith(fetch(e.request).then(function (r) {
      var copia = r.clone(); caches.open(VERSION).then(function (c) { c.put(e.request, copia); }); return r;
    }).catch(function () { return caches.match(e.request, { ignoreSearch: true }).then(function (r) { return r || caches.match('index.html'); }); }));
  } else if (url.hostname.indexOf('fonts.') === 0) {
    e.respondWith(caches.match(e.request).then(function (r) {
      return r || fetch(e.request).then(function (res) { var c = res.clone(); caches.open(VERSION).then(function (k) { k.put(e.request, c); }); return res; });
    }));
  }
});
